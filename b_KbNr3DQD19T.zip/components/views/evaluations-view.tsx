"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  ChevronDown,
  Download,
  Star,
  CheckCircle2,
  Clock,
  FileText,
  Send,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"

const evaluations = [
  {
    id: 1,
    pair: { mentee: "Katarzyna Wiśniewska", mentor: "Tomasz Dąbrowski" },
    programType: "Mentoring",
    endDate: "2024-01-05",
    menteeCompleted: true,
    mentorCompleted: true,
    menteeRating: 5,
    mentorRating: 4,
    sessions: 12,
  },
  {
    id: 2,
    pair: { mentee: "Anna Jabłońska", mentor: "Robert Kamiński" },
    programType: "Reverse",
    endDate: "2024-01-10",
    menteeCompleted: true,
    mentorCompleted: false,
    menteeRating: 4,
    mentorRating: null,
    sessions: 8,
  },
  {
    id: 3,
    pair: { mentee: "Michał Szymański", mentor: "Ewa Kowalczyk" },
    programType: "Mentoring",
    endDate: "2024-01-15",
    menteeCompleted: false,
    mentorCompleted: false,
    menteeRating: null,
    mentorRating: null,
    sessions: 6,
  },
  {
    id: 4,
    pair: { mentee: "Piotr Nowicki", mentor: "Maria Wójcik" },
    programType: "Peer",
    endDate: "2023-12-20",
    menteeCompleted: true,
    mentorCompleted: true,
    menteeRating: 5,
    mentorRating: 5,
    sessions: 10,
  },
]

const programTypeColors: Record<string, string> = {
  "Mentoring": "bg-primary/10 text-primary border-primary/20",
  "Peer": "bg-blue-50 text-blue-600 border-blue-200",
  "Reverse": "bg-purple-50 text-purple-600 border-purple-200",
}

// Stats
const evalStats = {
  total: 45,
  completed: 38,
  pending: 7,
  avgRating: 4.3,
}

export function EvaluationsView() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredEvaluations = evaluations.filter(
    (evaluation) =>
      evaluation.pair.mentee.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evaluation.pair.mentor.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const renderStars = (rating: number | null) => {
    if (rating === null) return <span className="text-muted-foreground text-sm">-</span>
    return (
      <div className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-4 h-4 ${
              star <= rating ? "fill-primary text-primary" : "text-muted-foreground/30"
            }`}
          />
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Ewaluacje</h1>
          <p className="text-muted-foreground">Ankiety końcowe i feedback uczestników</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Send className="w-4 h-4 mr-2" />
            Wyślij przypomnienia
          </Button>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Eksportuj
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <FileText className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{evalStats.total}</p>
                <p className="text-sm text-muted-foreground">Wszystkie</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-green-100 rounded-lg">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-green-600">{evalStats.completed}</p>
                <p className="text-sm text-muted-foreground">Wypełnione</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-yellow-100 rounded-lg">
                <Clock className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-yellow-600">{evalStats.pending}</p>
                <p className="text-sm text-muted-foreground">Oczekujące</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <Star className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{evalStats.avgRating}</p>
                <p className="text-sm text-muted-foreground">Średnia ocena</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Szukaj po nazwisku..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Status
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Wypełnione</DropdownMenuItem>
                <DropdownMenuItem>Oczekujące</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Program
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Mentoring klasyczny</DropdownMenuItem>
                <DropdownMenuItem>Peer Mentoring</DropdownMenuItem>
                <DropdownMenuItem>Reverse Mentoring</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Evaluations List */}
      <Card className="border-border">
        <CardHeader className="pb-0">
          <CardTitle className="text-lg">Ankiety ewaluacyjne</CardTitle>
          <CardDescription>Status ankiet końcowych dla zakończonych programów</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {filteredEvaluations.map((evaluation) => (
              <div
                key={evaluation.id}
                className="p-5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  {/* Pair info */}
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex -space-x-2 shrink-0">
                      <div className="w-10 h-10 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center z-10">
                        <span className="text-xs font-medium text-primary">
                          {evaluation.pair.mentee.charAt(0)}
                        </span>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-accent/50 border-2 border-card flex items-center justify-center">
                        <span className="text-xs font-medium text-accent-foreground">
                          {evaluation.pair.mentor.charAt(0)}
                        </span>
                      </div>
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {evaluation.pair.mentee}{" "}
                        <span className="text-muted-foreground">&</span> {evaluation.pair.mentor}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className={programTypeColors[evaluation.programType]}>
                          {evaluation.programType}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {evaluation.sessions} sesji · Zakończono {evaluation.endDate}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Evaluation status */}
                  <div className="grid grid-cols-2 gap-6 md:gap-8">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Mentee</p>
                      <div className="flex items-center gap-2">
                        {evaluation.menteeCompleted ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        ) : (
                          <Clock className="w-4 h-4 text-yellow-500" />
                        )}
                        {renderStars(evaluation.menteeRating)}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Mentor</p>
                      <div className="flex items-center gap-2">
                        {evaluation.mentorCompleted ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        ) : (
                          <Clock className="w-4 h-4 text-yellow-500" />
                        )}
                        {renderStars(evaluation.mentorRating)}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    {(!evaluation.menteeCompleted || !evaluation.mentorCompleted) && (
                      <Button variant="outline" size="sm" className="text-primary border-primary">
                        <Send className="w-4 h-4 mr-1" />
                        Przypomnij
                      </Button>
                    )}
                    <Button variant="ghost" size="sm">
                      Szczegóły
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Summary Card */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-lg">Podsumowanie ocen</CardTitle>
          <CardDescription>Rozkład ocen z ankiet ewaluacyjnych</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[5, 4, 3, 2, 1].map((rating) => {
              const count = rating === 5 ? 18 : rating === 4 ? 12 : rating === 3 ? 5 : rating === 2 ? 2 : 1
              const percentage = Math.round((count / 38) * 100)
              return (
                <div key={rating} className="flex items-center gap-4">
                  <div className="flex items-center gap-1 w-24 shrink-0">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`w-4 h-4 ${
                          star <= rating ? "fill-primary text-primary" : "text-muted-foreground/30"
                        }`}
                      />
                    ))}
                  </div>
                  <div className="flex-1">
                    <Progress value={percentage} className="h-2" />
                  </div>
                  <span className="text-sm text-muted-foreground w-16 text-right">
                    {count} ({percentage}%)
                  </span>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
