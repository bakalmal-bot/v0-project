"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  ChevronDown,
  MoreHorizontal,
  Calendar,
  Users,
  RefreshCw,
  XCircle,
  CheckCircle2,
  Clock,
  MessageSquare,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const pairs = [
  {
    id: 1,
    mentee: {
      name: "Jan Kowalski",
      position: "Product Manager",
      department: "Digital",
    },
    mentor: {
      name: "Piotr Zieliński",
      position: "Director",
      department: "Strategy",
    },
    programType: "Mentoring",
    status: "Aktywny",
    startDate: "2024-01-15",
    sessions: 4,
    lastSession: "2024-01-28",
    daysActive: 45,
  },
  {
    id: 2,
    mentee: {
      name: "Maria Nowak",
      position: "Software Engineer",
      department: "IT",
    },
    mentor: {
      name: "Adam Kamiński",
      position: "Tech Lead",
      department: "IT",
    },
    programType: "Peer",
    status: "Aktywny",
    startDate: "2024-01-10",
    sessions: 6,
    lastSession: "2024-02-01",
    daysActive: 50,
  },
  {
    id: 3,
    mentee: {
      name: "Robert Lewandowski",
      position: "Executive Director",
      department: "Marketing",
    },
    mentor: {
      name: "Anna Jabłońska",
      position: "Junior Analyst",
      department: "Digital",
    },
    programType: "Reverse",
    status: "Aktywny",
    startDate: "2024-01-05",
    sessions: 3,
    lastSession: "2024-01-20",
    daysActive: 55,
  },
  {
    id: 4,
    mentee: {
      name: "Katarzyna Wiśniewska",
      position: "HR Manager",
      department: "HR",
    },
    mentor: {
      name: "Tomasz Dąbrowski",
      position: "VP HR",
      department: "HR",
    },
    programType: "Mentoring",
    status: "Zakończony",
    startDate: "2023-07-01",
    sessions: 12,
    lastSession: "2024-01-05",
    daysActive: 180,
  },
  {
    id: 5,
    mentee: {
      name: "Michał Szymański",
      position: "Sales Rep",
      department: "Sales",
    },
    mentor: {
      name: "Ewa Kowalczyk",
      position: "Sales Director",
      department: "Sales",
    },
    programType: "Mentoring",
    status: "Wymaga uwagi",
    startDate: "2023-12-01",
    sessions: 2,
    lastSession: "2023-12-20",
    daysActive: 60,
  },
]

const statusConfig: Record<string, { color: string; icon: React.ReactNode }> = {
  "Aktywny": {
    color: "bg-green-100 text-green-700 border-green-200",
    icon: <CheckCircle2 className="w-3 h-3" />,
  },
  "Zakończony": {
    color: "bg-gray-100 text-gray-700 border-gray-200",
    icon: <CheckCircle2 className="w-3 h-3" />,
  },
  "Wymaga uwagi": {
    color: "bg-red-100 text-red-700 border-red-200",
    icon: <Clock className="w-3 h-3" />,
  },
}

const programTypeColors: Record<string, string> = {
  "Mentoring": "bg-primary/10 text-primary border-primary/20",
  "Peer": "bg-blue-50 text-blue-600 border-blue-200",
  "Reverse": "bg-purple-50 text-purple-600 border-purple-200",
}

export function PairsView() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredPairs = pairs.filter(
    (pair) =>
      pair.mentee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pair.mentor.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Pary mentoringowe</h1>
          <p className="text-muted-foreground">Zarządzaj parami mentor-mentee</p>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Users className="w-4 h-4 mr-2" />
          Utwórz parę
        </Button>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Szukaj po imieniu mentora lub mentee..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Program
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Mentoring klasyczny</DropdownMenuItem>
                <DropdownMenuItem>Peer Mentoring</DropdownMenuItem>
                <DropdownMenuItem>Reverse Mentoring</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Status
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Aktywne</DropdownMenuItem>
                <DropdownMenuItem>Zakończone</DropdownMenuItem>
                <DropdownMenuItem>Wymagają uwagi</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Pairs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredPairs.map((pair) => (
          <Card
            key={pair.id}
            className="border-border hover:border-primary/30 transition-colors"
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={programTypeColors[pair.programType]}>
                    {pair.programType}
                  </Badge>
                  <Badge
                    variant="outline"
                    className={`flex items-center gap-1 ${statusConfig[pair.status].color}`}
                  >
                    {statusConfig[pair.status].icon}
                    {pair.status}
                  </Badge>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Wyślij wiadomość
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Calendar className="w-4 h-4 mr-2" />
                      Dodaj sesję
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Zmień mentora
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-red-600">
                      <XCircle className="w-4 h-4 mr-2" />
                      Zakończ program
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Pair info */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex -space-x-3">
                  <div className="w-12 h-12 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center z-10">
                    <span className="text-sm font-medium text-primary">
                      {pair.mentee.name.charAt(0)}
                    </span>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-accent/50 border-2 border-card flex items-center justify-center">
                    <span className="text-sm font-medium text-accent-foreground">
                      {pair.mentor.name.charAt(0)}
                    </span>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-sm font-medium text-foreground truncate">
                      {pair.mentee.name}
                    </p>
                    <span className="text-muted-foreground text-xs">Mentee</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-foreground truncate">
                      {pair.mentor.name}
                    </p>
                    <span className="text-muted-foreground text-xs">Mentor</span>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 p-3 bg-muted/50 rounded-lg">
                <div className="text-center">
                  <p className="text-lg font-semibold text-foreground">{pair.sessions}</p>
                  <p className="text-xs text-muted-foreground">Sesji</p>
                </div>
                <div className="text-center border-x border-border">
                  <p className="text-lg font-semibold text-foreground">{pair.daysActive}</p>
                  <p className="text-xs text-muted-foreground">Dni aktywne</p>
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-foreground">{pair.lastSession}</p>
                  <p className="text-xs text-muted-foreground">Ostatnia sesja</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
