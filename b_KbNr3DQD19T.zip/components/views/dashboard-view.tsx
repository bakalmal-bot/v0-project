"use client"

import {
  Users,
  FileText,
  Calendar,
  TrendingUp,
  Clock,
  AlertCircle,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

const stats = [
  {
    title: "Aktywne pary",
    value: "42",
    change: "+8%",
    trend: "up",
    icon: Users,
    breakdown: "28 Mentoring · 9 Peer · 5 Reverse",
  },
  {
    title: "Nowe zgłoszenia",
    value: "5",
    change: "3 oczekują",
    trend: "neutral",
    icon: FileText,
    breakdown: "Do dopasowania",
  },
  {
    title: "Sesje w tym miesiącu",
    value: "127",
    change: "+12%",
    trend: "up",
    icon: Calendar,
    breakdown: "vs 113 poprzedni miesiąc",
  },
  {
    title: "Współczynnik ukończenia",
    value: "89%",
    change: "+2%",
    trend: "up",
    icon: TrendingUp,
    breakdown: "Programy zakończone z ewaluacją",
  },
]

const pendingActions = [
  {
    type: "application",
    title: "Jan Kowalski",
    subtitle: "Mentoring klasyczny · Przywództwo",
    date: "2 dni temu",
    priority: "high",
  },
  {
    type: "application",
    title: "Maria Nowak",
    subtitle: "Peer Mentoring · Technologie",
    date: "3 dni temu",
    priority: "medium",
  },
  {
    type: "reminder",
    title: "Para: Tomasz W. & Adam K.",
    subtitle: "Brak sesji od 35 dni",
    date: "Wymaga uwagi",
    priority: "high",
  },
  {
    type: "evaluation",
    title: "Ankieta końcowa",
    subtitle: "5 par do ewaluacji",
    date: "Termin: 7 dni",
    priority: "medium",
  },
]

const recentPairs = [
  {
    mentee: "Aleksandra Wiśniewska",
    mentor: "Piotr Zieliński",
    type: "Mentoring",
    status: "Aktywny",
    sessions: 4,
  },
  {
    mentee: "Michał Dąbrowski",
    mentor: "Katarzyna Lewandowska",
    type: "Peer",
    status: "Aktywny",
    sessions: 6,
  },
  {
    mentee: "Anna Jabłońska",
    mentor: "Robert Kamiński",
    type: "Reverse",
    status: "Zakończony",
    sessions: 8,
  },
]

export function DashboardView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Przegląd programów mentoringowych</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title} className="border-border">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-semibold text-foreground">{stat.value}</span>
                      <span
                        className={`text-xs flex items-center gap-0.5 ${
                          stat.trend === "up"
                            ? "text-green-600"
                            : stat.trend === "down"
                            ? "text-red-600"
                            : "text-muted-foreground"
                        }`}
                      >
                        {stat.trend === "up" && <ArrowUpRight className="w-3 h-3" />}
                        {stat.trend === "down" && <ArrowDownRight className="w-3 h-3" />}
                        {stat.change}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">{stat.breakdown}</p>
                  </div>
                  <div className="p-2.5 bg-primary/10 rounded-lg">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pending Actions */}
        <Card className="border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Do działania</CardTitle>
                <CardDescription>Zadania wymagające uwagi</CardDescription>
              </div>
              <Badge variant="secondary" className="bg-primary/10 text-primary">
                {pendingActions.length}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingActions.map((action, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
              >
                <div
                  className={`p-2 rounded-lg ${
                    action.priority === "high" ? "bg-red-100" : "bg-yellow-100"
                  }`}
                >
                  {action.type === "application" && (
                    <FileText
                      className={`w-4 h-4 ${
                        action.priority === "high" ? "text-red-600" : "text-yellow-600"
                      }`}
                    />
                  )}
                  {action.type === "reminder" && (
                    <Clock
                      className={`w-4 h-4 ${
                        action.priority === "high" ? "text-red-600" : "text-yellow-600"
                      }`}
                    />
                  )}
                  {action.type === "evaluation" && (
                    <AlertCircle
                      className={`w-4 h-4 ${
                        action.priority === "high" ? "text-red-600" : "text-yellow-600"
                      }`}
                    />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{action.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{action.subtitle}</p>
                </div>
                <span className="text-xs text-muted-foreground whitespace-nowrap">{action.date}</span>
              </div>
            ))}
            <Button variant="ghost" className="w-full text-primary hover:text-primary hover:bg-primary/5">
              Zobacz wszystkie
            </Button>
          </CardContent>
        </Card>

        {/* Recent Pairs */}
        <Card className="border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Ostatnie pary</CardTitle>
                <CardDescription>Najnowsze dopasowania</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                Zobacz wszystkie
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentPairs.map((pair, index) => (
                <div
                  key={index}
                  className="flex items-center gap-4 p-3 rounded-lg border border-border hover:border-primary/30 transition-colors cursor-pointer"
                >
                  <div className="flex -space-x-2">
                    <div className="w-9 h-9 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center">
                      <span className="text-xs font-medium text-primary">
                        {pair.mentee.charAt(0)}
                      </span>
                    </div>
                    <div className="w-9 h-9 rounded-full bg-accent/50 border-2 border-card flex items-center justify-center">
                      <span className="text-xs font-medium text-accent-foreground">
                        {pair.mentor.charAt(0)}
                      </span>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">
                      {pair.mentee} <span className="text-muted-foreground">&</span> {pair.mentor}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <Badge
                        variant="outline"
                        className={`text-xs ${
                          pair.type === "Mentoring"
                            ? "border-primary/30 text-primary"
                            : pair.type === "Peer"
                            ? "border-blue-300 text-blue-600"
                            : "border-purple-300 text-purple-600"
                        }`}
                      >
                        {pair.type}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{pair.sessions} sesji</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CheckCircle2
                      className={`w-4 h-4 ${
                        pair.status === "Aktywny" ? "text-green-500" : "text-muted-foreground"
                      }`}
                    />
                    <span className="text-xs text-muted-foreground">{pair.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Program Distribution */}
      <Card className="border-border">
        <CardHeader>
          <CardTitle className="text-lg">Rozkład programów</CardTitle>
          <CardDescription>Aktywne pary według typu programu</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-primary/5 border border-primary/20">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-foreground">Mentoring klasyczny</span>
                <span className="text-2xl font-semibold text-primary">28</span>
              </div>
              <div className="w-full h-2 bg-primary/10 rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: "67%" }} />
              </div>
              <p className="text-xs text-muted-foreground mt-2">67% wszystkich par</p>
            </div>
            <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-foreground">Peer Mentoring</span>
                <span className="text-2xl font-semibold text-blue-600">9</span>
              </div>
              <div className="w-full h-2 bg-blue-100 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: "21%" }} />
              </div>
              <p className="text-xs text-muted-foreground mt-2">21% wszystkich par</p>
            </div>
            <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-foreground">Reverse Mentoring</span>
                <span className="text-2xl font-semibold text-purple-600">5</span>
              </div>
              <div className="w-full h-2 bg-purple-100 rounded-full overflow-hidden">
                <div className="h-full bg-purple-500 rounded-full" style={{ width: "12%" }} />
              </div>
              <p className="text-xs text-muted-foreground mt-2">12% wszystkich par</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
