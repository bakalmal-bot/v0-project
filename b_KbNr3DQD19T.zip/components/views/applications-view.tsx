"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  Download,
  ChevronDown,
  Eye,
  UserPlus,
  MoreHorizontal,
  Calendar,
  Building2,
  Target,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const applications = [
  {
    id: 1,
    name: "Jan Kowalski",
    position: "Product Manager",
    department: "Digital",
    programType: "Mentoring",
    competencies: ["Przywództwo", "Zarządzanie zespołem"],
    preferredMentor: "Piotr Zieliński",
    status: "Oczekuje",
    date: "2024-01-15",
    daysWaiting: 2,
  },
  {
    id: 2,
    name: "Maria Nowak",
    position: "Software Engineer",
    department: "IT",
    programType: "Peer",
    competencies: ["Technologie", "Cloud"],
    preferredMentor: null,
    status: "Oczekuje",
    date: "2024-01-14",
    daysWaiting: 3,
  },
  {
    id: 3,
    name: "Tomasz Wiśniewski",
    position: "Junior Analyst",
    department: "Finance",
    programType: "Reverse",
    competencies: ["Social Media", "Digital Tools"],
    preferredMentor: "Dyrektor Marketing",
    status: "Oczekuje",
    date: "2024-01-12",
    daysWaiting: 5,
  },
  {
    id: 4,
    name: "Anna Jabłońska",
    position: "HR Specialist",
    department: "HR",
    programType: "Mentoring",
    competencies: ["Rozwój kariery", "Komunikacja"],
    preferredMentor: null,
    status: "W trakcie",
    date: "2024-01-10",
    daysWaiting: 7,
  },
  {
    id: 5,
    name: "Michał Dąbrowski",
    position: "Marketing Specialist",
    department: "Marketing",
    programType: "Peer",
    competencies: ["Marketing cyfrowy", "Analityka"],
    preferredMentor: "Katarzyna Lewandowska",
    status: "Para utworzona",
    date: "2024-01-08",
    daysWaiting: 0,
  },
]

const statusColors: Record<string, string> = {
  "Oczekuje": "bg-yellow-100 text-yellow-700 border-yellow-200",
  "W trakcie": "bg-blue-100 text-blue-700 border-blue-200",
  "Para utworzona": "bg-green-100 text-green-700 border-green-200",
}

const programTypeColors: Record<string, string> = {
  "Mentoring": "bg-primary/10 text-primary border-primary/20",
  "Peer": "bg-blue-50 text-blue-600 border-blue-200",
  "Reverse": "bg-purple-50 text-purple-600 border-purple-200",
}

export function ApplicationsView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedApplication, setSelectedApplication] = useState<number | null>(null)

  const filteredApplications = applications.filter(
    (app) =>
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.department.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Zgłoszenia</h1>
          <p className="text-muted-foreground">
            Zarządzaj zgłoszeniami do programów mentoringowych
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Eksportuj
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Szukaj po imieniu, dziale..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Program
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Mentoring klasyczny</DropdownMenuItem>
                <DropdownMenuItem>Peer Mentoring</DropdownMenuItem>
                <DropdownMenuItem>Reverse Mentoring</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Status
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Oczekuje na dopasowanie</DropdownMenuItem>
                <DropdownMenuItem>W trakcie</DropdownMenuItem>
                <DropdownMenuItem>Para utworzona</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-foreground">{applications.length}</p>
            <p className="text-sm text-muted-foreground">Wszystkie zgłoszenia</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-yellow-600">
              {applications.filter((a) => a.status === "Oczekuje").length}
            </p>
            <p className="text-sm text-muted-foreground">Oczekuje na dopasowanie</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-blue-600">
              {applications.filter((a) => a.status === "W trakcie").length}
            </p>
            <p className="text-sm text-muted-foreground">W trakcie</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-green-600">
              {applications.filter((a) => a.status === "Para utworzona").length}
            </p>
            <p className="text-sm text-muted-foreground">Dopasowane</p>
          </CardContent>
        </Card>
      </div>

      {/* Applications List */}
      <Card className="border-border">
        <CardHeader className="pb-0">
          <CardTitle className="text-lg">Lista zgłoszeń</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Osoba
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Program
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Kompetencje
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Preferowany mentor
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Status
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Akcje
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredApplications.map((app) => (
                  <tr
                    key={app.id}
                    className={`hover:bg-muted/50 transition-colors cursor-pointer ${
                      selectedApplication === app.id ? "bg-primary/5" : ""
                    }`}
                    onClick={() => setSelectedApplication(app.id)}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="text-sm font-medium text-primary">
                            {app.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{app.name}</p>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Building2 className="w-3 h-3" />
                            {app.position} · {app.department}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge
                        variant="outline"
                        className={programTypeColors[app.programType]}
                      >
                        {app.programType}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1">
                        {app.competencies.map((comp, i) => (
                          <Badge
                            key={i}
                            variant="secondary"
                            className="text-xs bg-muted text-muted-foreground"
                          >
                            {comp}
                          </Badge>
                        ))}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-foreground">
                        {app.preferredMentor || (
                          <span className="text-muted-foreground italic">Nie wskazano</span>
                        )}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col gap-1">
                        <Badge variant="outline" className={statusColors[app.status]}>
                          {app.status}
                        </Badge>
                        {app.daysWaiting > 0 && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {app.daysWaiting} dni
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-primary"
                        >
                          <UserPlus className="w-4 h-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="w-4 h-4 mr-2" />
                              Zobacz profil
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <UserPlus className="w-4 h-4 mr-2" />
                              Dopasuj mentora
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Target className="w-4 h-4 mr-2" />
                              Zmień status
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
