"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  ChevronDown,
  Plus,
  Calendar,
  CheckCircle2,
  Clock,
  Users,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

const sessions = [
  {
    id: 1,
    pair: { mentee: "Jan Kowalski", mentor: "Piotr Zieliński" },
    programType: "Mentoring",
    date: "2024-01-28",
    confirmedBy: "Mentee",
    confirmedAt: "2024-01-29",
  },
  {
    id: 2,
    pair: { mentee: "Maria Nowak", mentor: "Adam Kamiński" },
    programType: "Peer",
    date: "2024-02-01",
    confirmedBy: "Mentee",
    confirmedAt: "2024-02-01",
  },
  {
    id: 3,
    pair: { mentee: "Robert Lewandowski", mentor: "Anna Jabłońska" },
    programType: "Reverse",
    date: "2024-01-20",
    confirmedBy: "Koordynator",
    confirmedAt: "2024-01-25",
  },
  {
    id: 4,
    pair: { mentee: "Jan Kowalski", mentor: "Piotr Zieliński" },
    programType: "Mentoring",
    date: "2024-01-14",
    confirmedBy: "Mentee",
    confirmedAt: "2024-01-15",
  },
  {
    id: 5,
    pair: { mentee: "Jan Kowalski", mentor: "Piotr Zieliński" },
    programType: "Mentoring",
    date: "2024-01-02",
    confirmedBy: "Mentee",
    confirmedAt: "2024-01-03",
  },
]

const programTypeColors: Record<string, string> = {
  "Mentoring": "bg-primary/10 text-primary border-primary/20",
  "Peer": "bg-blue-50 text-blue-600 border-blue-200",
  "Reverse": "bg-purple-50 text-purple-600 border-purple-200",
}

// Statistics for cards
const sessionStats = {
  thisMonth: 127,
  lastMonth: 113,
  avgPerPair: 3.2,
  avgDaysBetween: 12,
}

export function SessionsView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const filteredSessions = sessions.filter(
    (session) =>
      session.pair.mentee.toLowerCase().includes(searchQuery.toLowerCase()) ||
      session.pair.mentor.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Sesje</h1>
          <p className="text-muted-foreground">Potwierdzanie i przeglądanie sesji mentoringowych</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" />
              Potwierdź sesję
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Potwierdź sesję</DialogTitle>
              <DialogDescription>
                Dodaj informację o odbytej sesji mentoringowej
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="pair">Para mentoringowa</Label>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="w-full justify-between">
                      Wybierz parę
                      <ChevronDown className="w-4 h-4 ml-2" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-full">
                    <DropdownMenuItem>Jan Kowalski & Piotr Zieliński</DropdownMenuItem>
                    <DropdownMenuItem>Maria Nowak & Adam Kamiński</DropdownMenuItem>
                    <DropdownMenuItem>Robert Lewandowski & Anna Jabłońska</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <div className="space-y-2">
                <Label htmlFor="date">Data sesji</Label>
                <Input type="date" id="date" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Anuluj
              </Button>
              <Button className="bg-primary text-primary-foreground" onClick={() => setIsDialogOpen(false)}>
                Potwierdź
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <Calendar className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{sessionStats.thisMonth}</p>
                <p className="text-sm text-muted-foreground">W tym miesiącu</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-muted rounded-lg">
                <Calendar className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{sessionStats.lastMonth}</p>
                <p className="text-sm text-muted-foreground">Poprzedni miesiąc</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-green-100 rounded-lg">
                <Users className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{sessionStats.avgPerPair}</p>
                <p className="text-sm text-muted-foreground">Śr. sesji/para</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-blue-100 rounded-lg">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{sessionStats.avgDaysBetween}</p>
                <p className="text-sm text-muted-foreground">Dni między sesjami</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Szukaj po nazwisku mentora lub mentee..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Program
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Mentoring klasyczny</DropdownMenuItem>
                <DropdownMenuItem>Peer Mentoring</DropdownMenuItem>
                <DropdownMenuItem>Reverse Mentoring</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Calendar className="w-4 h-4 mr-2" />
                  Okres
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Ostatni tydzień</DropdownMenuItem>
                <DropdownMenuItem>Ostatni miesiąc</DropdownMenuItem>
                <DropdownMenuItem>Ostatnie 3 miesiące</DropdownMenuItem>
                <DropdownMenuItem>Cały rok</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Sessions List */}
      <Card className="border-border">
        <CardHeader className="pb-0">
          <CardTitle className="text-lg">Historia sesji</CardTitle>
          <CardDescription>Chronologiczny wykaz potwierdzonych sesji</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {filteredSessions.map((session) => (
              <div
                key={session.id}
                className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors"
              >
                <div className="flex -space-x-2 shrink-0">
                  <div className="w-10 h-10 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center z-10">
                    <span className="text-xs font-medium text-primary">
                      {session.pair.mentee.charAt(0)}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-accent/50 border-2 border-card flex items-center justify-center">
                    <span className="text-xs font-medium text-accent-foreground">
                      {session.pair.mentor.charAt(0)}
                    </span>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">
                    {session.pair.mentee}{" "}
                    <span className="text-muted-foreground">&</span> {session.pair.mentor}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={programTypeColors[session.programType]}>
                      {session.programType}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      Potwierdzone przez: {session.confirmedBy}
                    </span>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="flex items-center gap-1.5 text-sm text-foreground">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    {session.date}
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                    <CheckCircle2 className="w-3 h-3 text-green-500" />
                    Potwierdzone {session.confirmedAt}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Mentee View - Simplified Session Confirmation */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">Panel Mentee</CardTitle>
              <CardDescription>Prosty widok dla mentee do potwierdzania sesji</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="text-center space-y-4">
              <div className="flex justify-center -space-x-3">
                <div className="w-16 h-16 rounded-full bg-primary/20 border-4 border-card flex items-center justify-center z-10">
                  <span className="text-lg font-medium text-primary">JK</span>
                </div>
                <div className="w-16 h-16 rounded-full bg-accent/50 border-4 border-card flex items-center justify-center">
                  <span className="text-lg font-medium text-accent-foreground">PZ</span>
                </div>
              </div>
              <div>
                <p className="text-lg font-medium text-foreground">
                  Twój mentor: Piotr Zieliński
                </p>
                <p className="text-sm text-muted-foreground">Director, Strategy</p>
              </div>
              <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <CheckCircle2 className="w-4 h-4 text-green-500" />
                4 sesje potwierdzone
              </div>
              <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
                <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                  <Plus className="w-4 h-4 mr-2" />
                  Potwierdź sesję
                </Button>
                <Button variant="outline" className="border-primary text-primary hover:bg-primary/5">
                  Zakończ program
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
