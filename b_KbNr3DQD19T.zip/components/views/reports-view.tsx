"use client"

import {
  BarChart3,
  Users,
  TrendingUp,
  PieChart,
  Download,
  Calendar,
  Filter,
  ChevronDown,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export function ReportsView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Raporty</h1>
          <p className="text-muted-foreground">
            Dashboardy i analizy programów mentoringowych
          </p>
        </div>
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Calendar className="w-4 h-4 mr-2" />
                Ostatnie 6 miesięcy
                <ChevronDown className="w-4 h-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>Ostatni miesiąc</DropdownMenuItem>
              <DropdownMenuItem>Ostatnie 3 miesiące</DropdownMenuItem>
              <DropdownMenuItem>Ostatnie 6 miesięcy</DropdownMenuItem>
              <DropdownMenuItem>Ostatni rok</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Eksportuj PDF
          </Button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Aktywne pary</p>
                <p className="text-3xl font-semibold text-foreground mt-1">42</p>
                <p className="text-xs text-green-600 mt-1">+8% vs poprzedni okres</p>
              </div>
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <Users className="w-5 h-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Sesje (6 mies.)</p>
                <p className="text-3xl font-semibold text-foreground mt-1">487</p>
                <p className="text-xs text-green-600 mt-1">+12% vs poprzedni okres</p>
              </div>
              <div className="p-2.5 bg-green-100 rounded-lg">
                <Calendar className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Współczynnik ukończenia</p>
                <p className="text-3xl font-semibold text-foreground mt-1">89%</p>
                <p className="text-xs text-green-600 mt-1">+2% vs poprzedni okres</p>
              </div>
              <div className="p-2.5 bg-blue-100 rounded-lg">
                <TrendingUp className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Średnia ocena</p>
                <p className="text-3xl font-semibold text-foreground mt-1">4.3</p>
                <p className="text-xs text-muted-foreground mt-1">Na skali 1-5</p>
              </div>
              <div className="p-2.5 bg-purple-100 rounded-lg">
                <BarChart3 className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Programs Distribution */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <PieChart className="w-5 h-5 text-primary" />
              Rozkład programów
            </CardTitle>
            <CardDescription>Aktywne pary według typu programu</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center gap-8">
              {/* Simplified pie chart representation */}
              <div className="relative w-40 h-40">
                <svg className="w-40 h-40 -rotate-90" viewBox="0 0 100 100">
                  <circle
                    className="text-muted stroke-current"
                    strokeWidth="20"
                    fill="transparent"
                    r="35"
                    cx="50"
                    cy="50"
                  />
                  <circle
                    className="text-primary stroke-current"
                    strokeWidth="20"
                    strokeDasharray={`${67 * 2.2} 220`}
                    strokeLinecap="round"
                    fill="transparent"
                    r="35"
                    cx="50"
                    cy="50"
                  />
                  <circle
                    className="text-blue-500 stroke-current"
                    strokeWidth="20"
                    strokeDasharray={`${21 * 2.2} 220`}
                    strokeDashoffset={`-${67 * 2.2}`}
                    strokeLinecap="round"
                    fill="transparent"
                    r="35"
                    cx="50"
                    cy="50"
                  />
                  <circle
                    className="text-purple-500 stroke-current"
                    strokeWidth="20"
                    strokeDasharray={`${12 * 2.2} 220`}
                    strokeDashoffset={`-${(67 + 21) * 2.2}`}
                    strokeLinecap="round"
                    fill="transparent"
                    r="35"
                    cx="50"
                    cy="50"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-2xl font-semibold text-foreground">42</p>
                    <p className="text-xs text-muted-foreground">pary</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-primary" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Mentoring</p>
                    <p className="text-xs text-muted-foreground">28 par (67%)</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Peer</p>
                    <p className="text-xs text-muted-foreground">9 par (21%)</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full bg-purple-500" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Reverse</p>
                    <p className="text-xs text-muted-foreground">5 par (12%)</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sessions Trend */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              Trend sesji
            </CardTitle>
            <CardDescription>Liczba sesji w ostatnich 6 miesiącach</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { month: "Sty", value: 127, percentage: 100 },
                { month: "Gru", value: 113, percentage: 89 },
                { month: "Lis", value: 98, percentage: 77 },
                { month: "Paź", value: 85, percentage: 67 },
                { month: "Wrz", value: 72, percentage: 57 },
                { month: "Sie", value: 42, percentage: 33 },
              ].map((item) => (
                <div key={item.month} className="flex items-center gap-4">
                  <span className="w-8 text-sm text-muted-foreground">{item.month}</span>
                  <div className="flex-1 h-6 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                  <span className="w-12 text-sm font-medium text-foreground text-right">
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Diversity Stats */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Różnorodność i inkluzywność
            </CardTitle>
            <CardDescription>Analiza uczestników programów</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-6">
              {/* Gender distribution */}
              <div>
                <p className="text-sm font-medium text-foreground mb-3">Płeć</p>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Mentees - Kobiety</span>
                      <span className="font-medium">58%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-pink-500 rounded-full" style={{ width: "58%" }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Mentorzy - Kobiety</span>
                      <span className="font-medium">45%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-pink-500 rounded-full" style={{ width: "45%" }} />
                    </div>
                  </div>
                </div>
              </div>
              {/* Cross-department */}
              <div>
                <p className="text-sm font-medium text-foreground mb-3">Pary międzydziałowe</p>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Różne działy</span>
                      <span className="font-medium">72%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full" style={{ width: "72%" }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-muted-foreground">Ten sam dział</span>
                      <span className="font-medium">28%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-muted-foreground rounded-full" style={{ width: "28%" }} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Management Levels */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              Poziomy zarządzania
            </CardTitle>
            <CardDescription>Rozkład mentorów według poziomu</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { level: "Dyrektor", count: 12, percentage: 40, color: "bg-primary" },
                { level: "N+2", count: 8, percentage: 27, color: "bg-blue-500" },
                { level: "N+1", count: 10, percentage: 33, color: "bg-green-500" },
              ].map((item) => (
                <div key={item.level}>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="font-medium text-foreground">{item.level}</span>
                    <span className="text-muted-foreground">
                      {item.count} mentorów ({item.percentage}%)
                    </span>
                  </div>
                  <div className="h-3 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color} rounded-full transition-all`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Operational Tasks */}
      <Card className="border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg">Raport operacyjny</CardTitle>
              <CardDescription>Zadania wymagające uwagi koordynatora</CardDescription>
            </div>
            <Button variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Eksportuj
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="bg-yellow-100 text-yellow-700 border-yellow-200">
                    Pilne
                  </Badge>
                  <span className="text-2xl font-semibold text-yellow-700">3</span>
                </div>
                <p className="text-sm text-yellow-700">Zgłoszenia oczekujące {">"}7 dni</p>
              </CardContent>
            </Card>
            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="bg-red-100 text-red-700 border-red-200">
                    Uwaga
                  </Badge>
                  <span className="text-2xl font-semibold text-red-700">5</span>
                </div>
                <p className="text-sm text-red-700">Pary bez sesji {">"}30 dni</p>
              </CardContent>
            </Card>
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
                    Do działania
                  </Badge>
                  <span className="text-2xl font-semibold text-blue-700">7</span>
                </div>
                <p className="text-sm text-blue-700">Ankiety do wypełnienia</p>
              </CardContent>
            </Card>
            <Card className="border-purple-200 bg-purple-50">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-200">
                    Planowanie
                  </Badge>
                  <span className="text-2xl font-semibold text-purple-700">4</span>
                </div>
                <p className="text-sm text-purple-700">Kończące się w 30 dni</p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
