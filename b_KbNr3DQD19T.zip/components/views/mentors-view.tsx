"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  ChevronDown,
  Download,
  MoreHorizontal,
  Edit,
  Mail,
  Award,
  Users,
  ExternalLink,
  CheckCircle,
  XCircle,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const mentors = [
  {
    id: 1,
    name: "Piotr Zieliński",
    position: "Director",
    department: "Strategy",
    gender: "M",
    managementLevel: "N+2",
    specializations: ["Przywództwo", "Strategia"],
    availableSlots: 2,
    activeSlots: 1,
    totalProcesses: 15,
    certifications: ["Certyfikat 1", "Certyfikat 2"],
    supervisions: 5,
    available: true,
    linkedIn: "https://linkedin.com/in/piotr-zielinski",
  },
  {
    id: 2,
    name: "Katarzyna Lewandowska",
    position: "VP Marketing",
    department: "Marketing",
    gender: "K",
    managementLevel: "Dyrektor",
    specializations: ["Marketing", "Digital"],
    availableSlots: 1,
    activeSlots: 1,
    totalProcesses: 22,
    certifications: ["Certyfikat 1"],
    supervisions: 8,
    available: false,
    linkedIn: "https://linkedin.com/in/katarzyna-lewandowska",
  },
  {
    id: 3,
    name: "Adam Kamiński",
    position: "Tech Lead",
    department: "IT",
    gender: "M",
    managementLevel: "N+1",
    specializations: ["Technologie", "Cloud", "Agile"],
    availableSlots: 3,
    activeSlots: 2,
    totalProcesses: 8,
    certifications: [],
    supervisions: 2,
    available: true,
    linkedIn: "https://linkedin.com/in/adam-kaminski",
  },
  {
    id: 4,
    name: "Ewa Kowalczyk",
    position: "Sales Director",
    department: "Sales",
    gender: "K",
    managementLevel: "Dyrektor",
    specializations: ["Sprzedaż", "Negocjacje"],
    availableSlots: 2,
    activeSlots: 2,
    totalProcesses: 18,
    certifications: ["Certyfikat 1", "Certyfikat 2"],
    supervisions: 6,
    available: false,
    linkedIn: "https://linkedin.com/in/ewa-kowalczyk",
  },
  {
    id: 5,
    name: "Tomasz Dąbrowski",
    position: "VP HR",
    department: "HR",
    gender: "M",
    managementLevel: "Dyrektor",
    specializations: ["HR", "Rozwój talentów", "Coaching"],
    availableSlots: 2,
    activeSlots: 0,
    totalProcesses: 30,
    certifications: ["Certyfikat 1", "Certyfikat 2"],
    supervisions: 12,
    available: true,
    linkedIn: "https://linkedin.com/in/tomasz-dabrowski",
  },
]

export function MentorsView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedMentors, setSelectedMentors] = useState<number[]>([])

  const filteredMentors = mentors.filter(
    (mentor) =>
      mentor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mentor.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      mentor.specializations.some((s) => s.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const toggleMentor = (id: number) => {
    setSelectedMentors((prev) =>
      prev.includes(id) ? prev.filter((m) => m !== id) : [...prev, id]
    )
  }

  const toggleAll = () => {
    if (selectedMentors.length === filteredMentors.length) {
      setSelectedMentors([])
    } else {
      setSelectedMentors(filteredMentors.map((m) => m.id))
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Lista mentorów</h1>
          <p className="text-muted-foreground">
            Zarządzaj mentorami i ich dostępnością
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selectedMentors.length > 0 && (
            <Button variant="outline" className="text-primary border-primary">
              <Mail className="w-4 h-4 mr-2" />
              Wyślij email ({selectedMentors.length})
            </Button>
          )}
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Eksportuj
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="border-border">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Szukaj po imieniu, dziale, specjalizacji..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Dostępność
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszyscy</DropdownMenuItem>
                <DropdownMenuItem>Dostępni</DropdownMenuItem>
                <DropdownMenuItem>Niedostępni</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Specjalizacja
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>Przywództwo</DropdownMenuItem>
                <DropdownMenuItem>Technologie</DropdownMenuItem>
                <DropdownMenuItem>Marketing</DropdownMenuItem>
                <DropdownMenuItem>HR</DropdownMenuItem>
                <DropdownMenuItem>Sprzedaż</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="shrink-0">
                  <Filter className="w-4 h-4 mr-2" />
                  Poziom
                  <ChevronDown className="w-4 h-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>Wszystkie</DropdownMenuItem>
                <DropdownMenuItem>N+1</DropdownMenuItem>
                <DropdownMenuItem>N+2</DropdownMenuItem>
                <DropdownMenuItem>Dyrektor</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-foreground">{mentors.length}</p>
            <p className="text-sm text-muted-foreground">Wszyscy mentorzy</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-green-600">
              {mentors.filter((m) => m.available).length}
            </p>
            <p className="text-sm text-muted-foreground">Dostępni</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-primary">
              {mentors.reduce((acc, m) => acc + m.activeSlots, 0)}
            </p>
            <p className="text-sm text-muted-foreground">Aktywne mentorings</p>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <p className="text-2xl font-semibold text-foreground">
              {mentors.filter((m) => m.certifications.length > 0).length}
            </p>
            <p className="text-sm text-muted-foreground">Z certyfikatami</p>
          </CardContent>
        </Card>
      </div>

      {/* Mentors List */}
      <Card className="border-border">
        <CardHeader className="pb-0">
          <CardTitle className="text-lg">Lista mentorów</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="w-12 px-6 py-4">
                    <Checkbox
                      checked={selectedMentors.length === filteredMentors.length}
                      onCheckedChange={toggleAll}
                    />
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Mentor
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Poziom
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Specjalizacje
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Sloty
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Doświadczenie
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Status
                  </th>
                  <th className="text-left text-xs font-medium text-muted-foreground uppercase tracking-wider px-6 py-4">
                    Akcje
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredMentors.map((mentor) => (
                  <tr key={mentor.id} className="hover:bg-muted/50 transition-colors">
                    <td className="px-6 py-4">
                      <Checkbox
                        checked={selectedMentors.includes(mentor.id)}
                        onCheckedChange={() => toggleMentor(mentor.id)}
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="text-sm font-medium text-primary">
                            {mentor.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="text-sm font-medium text-foreground">{mentor.name}</p>
                            {mentor.certifications.length > 0 && (
                              <Award className="w-4 h-4 text-primary" />
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {mentor.position} · {mentor.department}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="text-xs">
                        {mentor.managementLevel}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-1 max-w-xs">
                        {mentor.specializations.slice(0, 2).map((spec, i) => (
                          <Badge
                            key={i}
                            variant="secondary"
                            className="text-xs bg-muted text-muted-foreground"
                          >
                            {spec}
                          </Badge>
                        ))}
                        {mentor.specializations.length > 2 && (
                          <Badge variant="secondary" className="text-xs bg-muted text-muted-foreground">
                            +{mentor.specializations.length - 2}
                          </Badge>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Users className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-foreground">
                          {mentor.activeSlots}/{mentor.availableSlots}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm">
                        <p className="text-foreground font-medium">{mentor.totalProcesses} procesów</p>
                        <p className="text-xs text-muted-foreground">{mentor.supervisions} superwizji</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {mentor.available ? (
                        <Badge
                          variant="outline"
                          className="bg-green-100 text-green-700 border-green-200"
                        >
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Dostępny
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="bg-gray-100 text-gray-600 border-gray-200"
                        >
                          <XCircle className="w-3 h-3 mr-1" />
                          Zajęty
                        </Badge>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          asChild
                        >
                          <a href={mentor.linkedIn} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Edit className="w-4 h-4 mr-2" />
                              Edytuj profil
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Mail className="w-4 h-4 mr-2" />
                              Wyślij email
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Users className="w-4 h-4 mr-2" />
                              Zmień dostępność
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
