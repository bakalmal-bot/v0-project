"use client"

import {
  Settings,
  Users,
  Mail,
  Bell,
  Calendar,
  Shield,
  Globe,
  Save,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function SettingsView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-semibold text-foreground">Ustawienia</h1>
        <p className="text-muted-foreground">Konfiguracja aplikacji i preferencje</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 max-w-2xl">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Ogólne
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            Powiadomienia
          </TabsTrigger>
          <TabsTrigger value="programs" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Programy
          </TabsTrigger>
          <TabsTrigger value="access" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Dostępy
          </TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general">
          <div className="grid gap-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Globe className="w-5 h-5 text-primary" />
                  Ustawienia regionalne
                </CardTitle>
                <CardDescription>Język i format danych</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="language">Domyślny język</Label>
                    <select
                      id="language"
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="pl">Polski</option>
                      <option value="en">English</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Strefa czasowa</Label>
                    <select
                      id="timezone"
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                    >
                      <option value="europe/warsaw">Europe/Warsaw (CET)</option>
                      <option value="utc">UTC</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateFormat">Format daty</Label>
                  <select
                    id="dateFormat"
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                  >
                    <option value="dd-mm-yyyy">DD-MM-YYYY</option>
                    <option value="yyyy-mm-dd">YYYY-MM-DD</option>
                    <option value="mm-dd-yyyy">MM-DD-YYYY</option>
                  </select>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary" />
                  Dane koordynatora
                </CardTitle>
                <CardDescription>Informacje wyświetlane w powiadomieniach</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="coordName">Imię i nazwisko</Label>
                    <Input id="coordName" defaultValue="Anna Pulford" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="coordEmail">Email</Label>
                    <Input id="coordEmail" type="email" defaultValue="anna.pulford@orange.com" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="coordTitle">Tytuł</Label>
                  <Input id="coordTitle" defaultValue="Koordynator programu Mentoring" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications">
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Mail className="w-5 h-5 text-primary" />
                Konfiguracja powiadomień
              </CardTitle>
              <CardDescription>Automatyczne wysyłanie wiadomości email</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium text-foreground">Nowe zgłoszenie</p>
                    <p className="text-sm text-muted-foreground">
                      Powiadomienie do koordynatora o nowym zgłoszeniu
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium text-foreground">Utworzenie pary</p>
                    <p className="text-sm text-muted-foreground">
                      Powiadomienie do mentora i mentee o dopasowaniu
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium text-foreground">Przypomnienia o sesjach</p>
                    <p className="text-sm text-muted-foreground">
                      Automatyczne przypomnienia gdy brak sesji {">"}30 dni
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div>
                    <p className="font-medium text-foreground">Zakończenie programu</p>
                    <p className="text-sm text-muted-foreground">
                      Powiadomienie z ankietą ewaluacyjną
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>

              <div className="pt-4 border-t border-border">
                <div className="space-y-2">
                  <Label>Interwał przypomnień (dni bez sesji)</Label>
                  <Input type="number" defaultValue="30" className="max-w-xs" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Programs Settings */}
        <TabsContent value="programs">
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                Parametry programów
              </CardTitle>
              <CardDescription>Domyślne ustawienia dla programów mentoringowych</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Domyślny czas trwania programu (miesiące)</Label>
                  <Input type="number" defaultValue="6" />
                </div>
                <div className="space-y-2">
                  <Label>Minimalna liczba sesji do zakończenia</Label>
                  <Input type="number" defaultValue="1" />
                </div>
              </div>

              <div className="pt-4 border-t border-border">
                <p className="font-medium text-foreground mb-4">Aktywne typy programów</p>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 rounded-lg border border-primary/20 bg-primary/5">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-primary" />
                      <div>
                        <p className="font-medium text-foreground">Mentoring klasyczny</p>
                        <p className="text-sm text-muted-foreground">
                          Doświadczony mentor wspiera rozwój mentee
                        </p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg border border-blue-200 bg-blue-50">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-blue-500" />
                      <div>
                        <p className="font-medium text-foreground">Peer Mentoring</p>
                        <p className="text-sm text-muted-foreground">
                          Wzajemna nauka między równorzędnymi uczestnikami
                        </p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg border border-purple-200 bg-purple-50">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full bg-purple-500" />
                      <div>
                        <p className="font-medium text-foreground">Reverse Mentoring</p>
                        <p className="text-sm text-muted-foreground">
                          Młodszy pracownik dzieli się wiedzą ze starszym
                        </p>
                      </div>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Access Settings */}
        <TabsContent value="access">
          <Card className="border-border">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Zarządzanie dostępem
              </CardTitle>
              <CardDescription>Koordynatorzy i uprawnienia</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-medium text-primary">AP</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Anna Pulford</p>
                      <p className="text-sm text-muted-foreground">anna.pulford@orange.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-primary font-medium">Administrator</span>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                      <span className="text-sm font-medium text-muted-foreground">MK</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Marta Kowalska</p>
                      <p className="text-sm text-muted-foreground">marta.kowalska@orange.com</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Koordynator</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  <Users className="w-4 h-4 mr-2" />
                  Dodaj koordynatora
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Save className="w-4 h-4 mr-2" />
          Zapisz zmiany
        </Button>
      </div>
    </div>
  )
}
