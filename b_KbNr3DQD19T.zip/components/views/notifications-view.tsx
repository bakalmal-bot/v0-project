"use client"

import { useState } from "react"
import {
  Mail,
  Send,
  FileText,
  Edit,
  Eye,
  CheckCircle2,
  Clock,
  Users,
  RefreshCw,
  XCircle,
  Plus,
} from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const notificationTemplates = [
  {
    id: 1,
    name: "Dopasowanie pary",
    type: "pair_created",
    description: "Wysyłane do mentora i mentee po utworzeniu pary",
    languages: ["PL", "EN"],
    lastEdited: "2024-01-15",
  },
  {
    id: 2,
    name: "Nowe zgłoszenie",
    type: "new_application",
    description: "Wysyłane do koordynatora po nowym zgłoszeniu",
    languages: ["PL", "EN"],
    lastEdited: "2024-01-10",
  },
  {
    id: 3,
    name: "Przypomnienie o sesji",
    type: "session_reminder",
    description: "Wysyłane gdy para nie raportowała sesji >30 dni",
    languages: ["PL", "EN"],
    lastEdited: "2024-01-08",
  },
  {
    id: 4,
    name: "Zakończenie programu",
    type: "program_end",
    description: "Wysyłane po zakończeniu programu z linkiem do ankiety",
    languages: ["PL", "EN"],
    lastEdited: "2024-01-05",
  },
  {
    id: 5,
    name: "Zmiana mentora",
    type: "mentor_change",
    description: "Wysyłane przy zmianie mentora w trakcie programu",
    languages: ["PL"],
    lastEdited: "2024-01-02",
  },
]

const notificationLog = [
  {
    id: 1,
    type: "pair_created",
    recipients: ["jan.kowalski@orange.com", "piotr.zielinski@orange.com"],
    subject: "Witaj w procesie mentoringowym",
    sentAt: "2024-01-28 14:32",
    status: "delivered",
  },
  {
    id: 2,
    type: "new_application",
    recipients: ["anna.pulford@orange.com"],
    subject: "Nowe zgłoszenie do programu mentoringowego",
    sentAt: "2024-01-28 10:15",
    status: "delivered",
  },
  {
    id: 3,
    type: "session_reminder",
    recipients: ["michal.szymanski@orange.com"],
    subject: "Przypomnienie: Raportowanie sesji mentoringowych",
    sentAt: "2024-01-27 09:00",
    status: "delivered",
  },
  {
    id: 4,
    type: "program_end",
    recipients: ["katarzyna.wisniewska@orange.com", "tomasz.dabrowski@orange.com"],
    subject: "Gratulacje! Program mentoringowy zakończony",
    sentAt: "2024-01-25 16:45",
    status: "delivered",
  },
  {
    id: 5,
    type: "session_reminder",
    recipients: ["anna.jablonska@orange.com"],
    subject: "Przypomnienie: Raportowanie sesji mentoringowych",
    sentAt: "2024-01-24 09:00",
    status: "failed",
  },
]

const typeIcons: Record<string, React.ReactNode> = {
  pair_created: <Users className="w-4 h-4" />,
  new_application: <FileText className="w-4 h-4" />,
  session_reminder: <Clock className="w-4 h-4" />,
  program_end: <CheckCircle2 className="w-4 h-4" />,
  mentor_change: <RefreshCw className="w-4 h-4" />,
}

const typeColors: Record<string, string> = {
  pair_created: "bg-green-100 text-green-700",
  new_application: "bg-blue-100 text-blue-700",
  session_reminder: "bg-yellow-100 text-yellow-700",
  program_end: "bg-purple-100 text-purple-700",
  mentor_change: "bg-orange-100 text-orange-700",
}

export function NotificationsView() {
  const [activeTab, setActiveTab] = useState("templates")

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Powiadomienia</h1>
          <p className="text-muted-foreground">
            Zarządzaj szablonami i przeglądaj historię wysyłek
          </p>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          Nowy szablon
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-primary/10 rounded-lg">
                <Mail className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">156</p>
                <p className="text-sm text-muted-foreground">Wysłane (miesiąc)</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-green-100 rounded-lg">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-green-600">98%</p>
                <p className="text-sm text-muted-foreground">Dostarczonych</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-blue-100 rounded-lg">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-foreground">{notificationTemplates.length}</p>
                <p className="text-sm text-muted-foreground">Szablonów</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-red-100 rounded-lg">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold text-red-600">3</p>
                <p className="text-sm text-muted-foreground">Błędy dostarczenia</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="templates">Szablony</TabsTrigger>
          <TabsTrigger value="history">Historia wysyłek</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="mt-6">
          <Card className="border-border">
            <CardHeader className="pb-0">
              <CardTitle className="text-lg">Szablony powiadomień</CardTitle>
              <CardDescription>
                Edytuj treść i konfiguruj szablony wiadomości email
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {notificationTemplates.map((template) => (
                  <div
                    key={template.id}
                    className="flex items-center gap-4 p-5 hover:bg-muted/50 transition-colors"
                  >
                    <div className={`p-2.5 rounded-lg ${typeColors[template.type]}`}>
                      {typeIcons[template.type]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{template.name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{template.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        {template.languages.map((lang) => (
                          <Badge
                            key={lang}
                            variant="outline"
                            className="text-xs"
                          >
                            {lang}
                          </Badge>
                        ))}
                        <span className="text-xs text-muted-foreground">
                          Edytowano: {template.lastEdited}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm">
                        <Eye className="w-4 h-4 mr-1" />
                        Podgląd
                      </Button>
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4 mr-1" />
                        Edytuj
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Send className="w-4 h-4 mr-1" />
                        Test
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <Card className="border-border">
            <CardHeader className="pb-0">
              <CardTitle className="text-lg">Historia wysyłek</CardTitle>
              <CardDescription>Log wszystkich wysłanych powiadomień</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border">
                {notificationLog.map((log) => (
                  <div
                    key={log.id}
                    className="flex items-center gap-4 p-5 hover:bg-muted/50 transition-colors"
                  >
                    <div className={`p-2.5 rounded-lg ${typeColors[log.type]}`}>
                      {typeIcons[log.type]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{log.subject}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 truncate">
                        Do: {log.recipients.join(", ")}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="flex items-center gap-1.5 justify-end">
                        {log.status === "delivered" ? (
                          <CheckCircle2 className="w-4 h-4 text-green-500" />
                        ) : (
                          <XCircle className="w-4 h-4 text-red-500" />
                        )}
                        <span
                          className={`text-xs ${
                            log.status === "delivered"
                              ? "text-green-600"
                              : "text-red-600"
                          }`}
                        >
                          {log.status === "delivered" ? "Dostarczono" : "Błąd"}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{log.sentAt}</p>
                    </div>
                    <Button variant="ghost" size="sm">
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Template Preview */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <div className="flex items-center gap-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Mail className="w-5 h-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">Podgląd szablonu: Dopasowanie pary</CardTitle>
              <CardDescription>Wersja polska</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="border-b border-border pb-4 mb-4">
              <p className="text-sm text-muted-foreground">
                <strong>Temat:</strong> Witaj w procesie mentoringowym
              </p>
            </div>
            <div className="prose prose-sm max-w-none text-foreground">
              <p>Witaj w procesie mentoringowym!</p>
              <p>
                Zapraszamy Cię do współpracy z Mentorem, którym będzie{" "}
                <span className="text-primary font-medium">{"{ImięMentora}"}</span> -{" "}
                <span className="text-primary font-medium">{"{DziałMentora}"}</span>.
              </p>
              <p>
                Skontaktuj się z Mentorem i umów się jak najwcześniej na sesję wstępną.
                Optymalny czas na jej przeprowadzenie to 14 dni.
              </p>
              <p className="text-muted-foreground">
                Przygotuj się do sesji wstępnej. Istotne jest odpowiedzenie sobie na
                pytanie, nad jakim tematem chcesz pracować? Co jest wyzwaniem, z którym
                się mierzysz? Co chcesz osiągnąć w ramach mentoringu?
              </p>
              <div className="mt-4 p-3 bg-muted rounded-lg">
                <p className="text-sm font-medium mb-2">Twoim zadaniem będzie:</p>
                <ul className="text-sm space-y-1">
                  <li>• umawianie spotkań z Mentorem</li>
                  <li>• rejestrowanie przeprowadzonych spotkań w panelu Mentee</li>
                  <li>• zakończenie procesu po przeprowadzeniu wszystkich spotkań</li>
                </ul>
              </div>
              <p className="mt-4">
                W razie pytań zapraszam do kontaktu.
                <br />
                Pozdrawiam,
                <br />
                <span className="text-primary font-medium">Anna Pulford</span>
                <br />
                <span className="text-muted-foreground">Koordynator programu Mentoring</span>
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
